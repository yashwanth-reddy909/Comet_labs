var express = require('express');
var router = express.Router();
const bodyParser=require('body-parser');
/* GET home page. */
var instance = require("../axios")


router.route('/repos')
.get( (req, res, next) => {
  
  instance.get("/repos/yashwanth-reddy909/")
  .then((response) => {
    res.status(200).json(response.data);
  })
  .catch(err=>console.log(err));  
})
.post((req,res,next)=>{
  
});

module.exports = router;
